
'use client'
import React from "react";
import Slider from "./Swiper";
const Abc = () => {
    return (
       <section className="container mt-50 text-light">
        <Slider></Slider>
       </section>
    )
}
export default Abc